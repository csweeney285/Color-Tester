//
//  main.m
//  Conor Sweeney - Color Tester Test
//
//  Created by Conor Sweeney on 11/20/15.
//  Copyright © 2015 Conor Sweeney. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
