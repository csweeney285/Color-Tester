//
//  AppDelegate.h
//  Conor Sweeney - Color Tester Test
//
//  Created by Conor Sweeney on 11/20/15.
//  Copyright © 2015 Conor Sweeney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

